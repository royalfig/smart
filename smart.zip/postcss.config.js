module.exports = {
  plugins: {
    autoprefixer: { grid: 'autoplace' },
    'postcss-preset-env': {},
    cssnano: {},
  },
};
