/*
* Set initial preference for color mode
TODO Confirm behavior for unsupported browsers
*/
