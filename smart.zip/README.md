# Smart: A Ghost Theme for Smart People

